<html>
 	<head>
 		
 		 <script type="text/javascript" src="http://solulabdev.com/fred-v2/js/jquery-1.11.2.min.js"></script>  

 		 <title>JSon</title>
 		<script type="text/javascript">
 			var jsonData = new Object;
 			$(document).ready(function(){
 				$.ajax({
 					 url: "content.php", 
 					 success: function(result){
						jsonData = result;
						
						var strMainSelect = "";
						if(result['Claims'].length > 0) {
							
							strMainSelect = '<select name="lstMain" id="lstMain">';
							
							$.each(result['Claims'], function(index1, value1){
								var selectValue = value1["Claimtype"]["name"];
								var selectKey = value1["Claimtype"]["id"];
								strMainSelect += '<option value="'+selectKey+'">'+selectValue+'</option>';
							});

							strMainSelect += '</select>';

						}
						$('#div1').html(strMainSelect);
						$('#div2').html("");
						$('#div3').html("");

						$('#lstMain').on('change', function(){
							var mainSelectValue = $(this).find("option:selected").attr('value');
							var strSecondSelect = "";

							$.each(jsonData['Claims'], function(index2, value2){
								var selectValue = value2["Claimtype"]["name"];
								var selectKey = value2["Claimtype"]["id"];

								if(mainSelectValue == selectKey) {
									var secondObject = new Object;

									if(value2["Claimtypedetail"].length > 0) {

										strSecondSelect = '<select name="lstSecond" id="lstSecond">';

										$.each(value2["Claimtypedetail"], function(index3, value3){
											var labelToDisplay = value3["Claimfield"]["label"];
											var idToSet = value3["Claimfield"]["id"];
											strSecondSelect += '<option value="'+idToSet+'">'+labelToDisplay+'</option>';
										});

										strSecondSelect += '</select>';
									}
								}
							});
							$('#div2').html(strSecondSelect);
							$('#div3').html("");

							$("#lstSecond").on('change', function(){
								var secondSelectValue = $(this).find("option:selected").attr('value');
								var strThirdSelect = "";
								var mainSelectValue = $('#lstMain').find("option:selected").attr('value');;

								$.each(jsonData['Claims'], function(index1, value1){
									var claimId = value1["Claimtype"]["id"];

									if(mainSelectValue == claimId) {
										var claimTypeDetail = new Object;
										claimTypeDetail = value1["Claimtypedetail"];
										$.each(claimTypeDetail, function(index2, value2){
											$.each(value2["Claimfield"], function(index3, value3){
												if($.type(value3) === "array") {
													if(value3.length > 0) {
														strThirdSelect = '<select name="lstThird" id="lstThird">';
														$.each(value3, function(index5, value5){
															var lastValue = value5["name"];
															var lastKey = value5["id"];
															strThirdSelect += '<option value="'+lastKey+'">'+lastValue+'</option>';
														});
														strThirdSelect += '</select>';
													}
												}
											});
										});
									}
								});
								$('#div3').html(strThirdSelect);
							});
						});
					}
				});

 			});

 		</script>
	</head>
	<body>
		<div id="div1">
			
		</div>

		<div id="div2">
			
		</div>

		<div id="div3">
			
		</div>

	</body>
</html>
